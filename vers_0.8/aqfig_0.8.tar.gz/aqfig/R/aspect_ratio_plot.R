## ###########################################################
##   2013-11-08 (JLS): This function is marked as defunct, since it
##     has been moved to package "figdim".
## ###########################################################
aspect.ratio.plot <- function(...){
  .Defunct("aspect.ratio.plot", package="figdim", msg="'aspect.ratio.plot' has been moved to package 'figdim'.  See www.people.vcu.edu/~jswall/figdim_index.html")
}
