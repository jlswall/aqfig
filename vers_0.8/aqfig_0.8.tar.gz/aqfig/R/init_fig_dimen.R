## #############################################################
##   2012-11-08 (JLS): This function is marked as defunct, since it
##     has been moved to package "figdim".
## ###########################################################
init.fig.dimen <- function(...){
    .Defunct("init.fig.dimen", package="figdim", msg="'init.fig.dimen' has been moved to package 'figdim'.  See www.people.vcu.edu/~jswall/figdim_index.html")
}
